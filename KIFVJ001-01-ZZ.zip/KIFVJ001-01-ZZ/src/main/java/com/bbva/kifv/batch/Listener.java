package com.bbva.kifv.batch;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.annotation.OnSkipInRead;
import org.springframework.batch.core.annotation.OnWriteError;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.PassThroughLineAggregator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.core.io.FileSystemResource;

import com.bbva.kifv.dto.fup.RegistryContracts;
import com.bbva.mmtp.lib.rrea.MMTPRREA;

public class Listener implements ItemReadListener<RegistryContracts>,ChunkListener,Tasklet{

	private static final Logger LOGGER = LoggerFactory.getLogger(Listener.class);
	 
	private FlatFileItemWriter<String> writerErrors = new FlatFileItemWriter<>();
	
    private MMTPRREA mmtpRREA;
    private String date;
    private String process;
    	
    public void setMmtpRREA(MMTPRREA mmtpRREA) {
		this.mmtpRREA = mmtpRREA;
	}
    
	public void setDate(String date) {
		this.date = date;
	}

	public void setProcess(String process) {
		this.process = process;
	}
	
    @OnSkipInRead
    public void onSkipInRead(Throwable t) throws Exception {		
		writeFile(t.getMessage());
    }
    
    @OnWriteError
    public void onWriteError(Exception exception, List<? extends RegistryContracts> writeList) throws Exception {
		LOGGER.info("Exception: {}" , exception.getMessage());	
		writeFile(exception.getMessage());
	}
	
	@Override
	public void afterChunk(ChunkContext chunk) {
		Integer readCount = chunk.getStepContext().getStepExecution().getReadCount();
		Integer skipReadCount = chunk.getStepContext().getStepExecution().getReadSkipCount();
						
			chunk.getStepContext().getStepExecution().getJobExecution()
			.getExecutionContext().put("readCount", readCount);
			
			chunk.getStepContext().getStepExecution().getJobExecution()
			.getExecutionContext().put("skipReadCount", skipReadCount);
		 
		LOGGER.info("After Read Count: {}" , readCount);
		LOGGER.info("After Read Skip : {}"  , skipReadCount);
	}

	@Override
	public void afterChunkError(ChunkContext chunk) {/****/
	}

	@Override
	public void beforeChunk(ChunkContext chunk) {/****/	}

	@Override
	public RepeatStatus execute(StepContribution step, ChunkContext chunk) throws Exception {
		
		 Map<String, Object> parameters = chunk.getStepContext().getJobExecutionContext();
		 
		 Integer skipReadCount = (Integer) parameters.get("skipReadCount");
		 Integer readCount = (Integer) parameters.get("readCount");
		 
		Map<String, Object> mapCif = mmtpRREA.executeSelectReaMap(process, dateProcess());
		
		String contextError = "error Skip:" + skipReadCount + " readCount:"+readCount;
		contextError = contextError + " ReadTotal:" + mapCif.get("REGS");
		
		writeFile(contextError);
	
		return RepeatStatus.FINISHED;
	}
	
	private void writeFile(String stringError) throws Exception{
		String fileErrors = "/fichtemcomp/datsal/MKIFV_D02_"+date+"_FONDOSCIF.txt";
		writerErrors.setResource(new FileSystemResource(fileErrors));
		writerErrors.setShouldDeleteIfEmpty(false);
		writerErrors.setAppendAllowed(true);
		PassThroughLineAggregator<String> agregaErrores= new PassThroughLineAggregator<>();
		writerErrors.setLineAggregator(agregaErrores);
		writerErrors.open(new ExecutionContext());		
		writerErrors.write(Arrays.asList(agregaErrores.aggregate(stringError)) );	
	}
	
	private String dateProcess(){		
		return	date.substring(0,4) + "/" +  date.substring(4,6) + "/" + date.substring(6,date.length()) ;
	}
	
	@Override
	public void afterRead(RegistryContracts registry) { /***/ }

	@Override
	public void beforeRead() { /***/ }

	@Override
	public void onReadError(Exception error){	
				 
		if(date!=null){
			
	        Map<String, Object> paramInput = new HashMap<>();
	        paramInput.put("UPD" ,  "0"); 
	        paramInput.put("INS" ,  "0"); 
	        paramInput.put("IDPROCESS",	 "KIFVJ001");
	        paramInput.put("PROCESS",    process);
	        paramInput.put("FORMATDATE", "yyyy/mm/dd");
	        paramInput.put("ENTITYID",   "0074");
	        paramInput.put("CUSTOM",     "KIFV"); 		
	        paramInput.put("DATEPROCESS", dateProcess());
            paramInput.put("REGS",  "1"); /*READ*/
            
			mmtpRREA.executeInsUpdateRea(paramInput);			
		}
	}	
}
