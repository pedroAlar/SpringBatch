package com.bbva.kifv.batch;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.bbva.mmtp.lib.rrea.MMTPRREA;

public class Reboot implements Tasklet{

	private MMTPRREA mmtpRREA;
	private String date;
	private String process;
		 
	public void setMmtpRREA(MMTPRREA mmtpRREA) {
		this.mmtpRREA = mmtpRREA;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setProcess(String process) {
		this.process = process;
	}


	@Override
	public RepeatStatus execute(StepContribution step, ChunkContext chunk) throws Exception {
		/***20221128**/
		String dateProcess = date.substring(0,4) + "/" +  date.substring(4,6) + "/" + date.substring(6,date.length()) ;
				
		Long skipReboot = mmtpRREA.executeSelectRea(process, dateProcess);
				
		chunk.getStepContext().getStepExecution().getJobExecution()
		.getExecutionContext().put("skipValue", skipReboot);	

		return RepeatStatus.FINISHED;
	}

}
