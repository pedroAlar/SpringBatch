package com.bbva.kifv.batch.mongo;

public class ColumnsNames {
	public static final String DATA_DATE = "gf_data_date";
    
	public static final String PRODUCT_TYPE = "gf_product_type";
	                          
	public static final String PRODUCT_ID = "gf_commercial_product_id";
	                          
	public static final String CONTRACT_ID = "g_contract_id";
	                          
	public static final String COUNTRY_ID = "gf_contract_country_id";
	                          
	public static final String ENTITY_ID = "gf_contract_entity_id";
	                            
	public static final String COUNTERPART_ID = "gf_counterpart_id";
	                            
	public static final String DEPENDENCY_ID = "gf_contract_dependency_id";
	                           
	public static final String IUC = "gf_contract_id";

	public static final String ISIN = "g_isin_id";
	                            
	public static final String MARKET_ID = "gf_market_id";
	                            
	public static final String PARENT_ID = "gf_portfolio_parent_id";
	                           
	public static final String PRODUCT_AMOUNT = "gf_investment_product_amount";
	                           
	public static final String VALUE_DATE = "gf_value_date";
	                           
	public static final String CURRENCY_ID = "gf_currency_id";
	                           
	public static final String QTN_AMOUNT_EUR = "gf_eu_prd_qtn_amount";
	                          
	public static final String IMP_VALIQ_EUR = "gf_settl_amount";
	                         
	public static final String EQUITY_AMOUNT_EUR = "gf_euros_equity_amount";
	                         
	public static final String CONTRIBUTION_AMOUNT_EUR = "gf_euros_contribution_amount";
	                            
	public static final String DETRACTIONS_AMOUNT_EUR = "gf_euros_detractions_amount";
	                          
	public static final String NET_CONT_AMOUNT_EUR = "gf_euros_net_cont_amount";
	                          
	public static final String CURNCY_EXPENSE_AMOUNT = "gf_curncy_expense_amount";
	                          
	public static final String INCOME_AMOUNT = "gf_income_amount";
	                          
	public static final String DERIVED_PRFT_AMOUNT_EUR = "gf_euros_derived_prft_amount";
	                          
	public static final String PROFITABILITY_AMOUNT = "gf_profitability_amount";
	                          
	public static final String QTN_AMOUNT = "gf_lcur_qtn_amount";
	                          
	public static final String SETTL_AMOUNT = "gf_lcur_settl_amount";
	                          
	public static final String LCUR_EQUITY_AMOUNT = "gf_lcur_equity_amount";
	                          
	public static final String CONT_AMOUNT = "gf_lcur_cont_amount";
	                          
	public static final String DETRACTIONS_AMOUNT_LCUR = "gf_lcur_detractions_amount";
	                          
	public static final String NET_CONT_AMOUNT_LCUR = "gf_lcur_net_cont_amount";
	                          
	public static final String EXPENSES_AMOUNT = "gf_lcur_expenses_amount";
	                          
	public static final String INCOME_AMOUNT_LCUR = "gf_lcur_income_amount";
	                          
	public static final String DERIVED_PROFIT_AMOUNT = "gf_lcur_derived_profit_amount";
	                          
	public static final String DAILY_PROFIT_AMOUNT = "gf_lcur_daily_profit_amount";
	                          
	public static final String TRANSFER_IND_TYPE = "gf_transfer_ind_type";
	                          
	public static final String REBALANCER_IND_TYPE = "gf_rebalancer_ind_type";
	                          
	public static final String AUDIT_INSERTION_USER_ID = "gf_audit_insertion_user_id";
	                          
	public static final String AUDIT_INSERT_DATE = "gf_opern_audit_insert_date";
	                          
	private ColumnsNames() {}
}
