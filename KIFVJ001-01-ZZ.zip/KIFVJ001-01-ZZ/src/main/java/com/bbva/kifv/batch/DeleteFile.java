package com.bbva.kifv.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.List;

public class DeleteFile  implements Tasklet {

    //Variables
    private List<String> files;
    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteFile.class);

    //Getter y Setter
    public List<String> getFiles() {
        return files;
    }
    public void setFiles(List<String> files) {
        this.files = files;
    }


    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws IOException {
        LOGGER.info("KIFVJ001 - DeleteFile - START");

        deleteFilesFromList();
        
        LOGGER.info("KIFVJ001 - DeleteFile - END");
                
        return RepeatStatus.FINISHED;
    }


    public void deleteFilesFromList() throws IOException {
        for (String filePath : files) {
            filePath=filePath.substring(5);
            Path path = Paths.get( filePath );
            Files.delete(path);

            String message = MessageFormat.format("KIFVJ001 - DeleteFile - Deleted file: {0}", path);
            LOGGER.info(message);
        }
    }

}
