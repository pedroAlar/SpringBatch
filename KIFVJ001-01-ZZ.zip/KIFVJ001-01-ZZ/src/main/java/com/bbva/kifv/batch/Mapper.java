package com.bbva.kifv.batch;

import com.bbva.kifv.batch.mongo.ColumnsNames;
import com.bbva.kifv.batch.utils.Constants;
import com.bbva.kifv.batch.utils.Utils;
import com.bbva.kifv.dto.fup.RegistryContracts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class Mapper implements  FieldSetMapper<RegistryContracts> {

	private static final Logger LOGGER = LoggerFactory.getLogger(Mapper.class);

	@Override
	public RegistryContracts mapFieldSet(FieldSet fileLine) {
		LOGGER.info("KIFVJ001 - Mapper - START");
		RegistryContracts registryContract = new RegistryContracts();


		String dataDateS = fileLine.readString(ColumnsNames.DATA_DATE);


		if (dataDateS != null) {
			LocalDate localDate= LocalDate.of(Integer.parseInt(dataDateS.substring(0, 4)),Integer.parseInt(dataDateS.substring(5, 7)),Integer.parseInt(dataDateS.substring(8,10)));

			Date dataDate = Date.from(localDate.atStartOfDay(ZoneId.of(Constants.TIMEZONE_UTC)).toInstant());
			if (dataDate == null) {
				throw new IllegalArgumentException();
			}else{
				registryContract.setDate(dataDate);
			}
		}

		registryContract.setProductTypeId( fileLine.readString(ColumnsNames.PRODUCT_TYPE));
		registryContract.setSaleUnitId(fileLine.readString(ColumnsNames.PRODUCT_ID));

		String contractId = fileLine.readString(ColumnsNames.CONTRACT_ID);
		if (contractId==null || "".equals(contractId.trim())){
			throw new IllegalArgumentException();
		}else{
			registryContract.setContractId(contractId);
		}

		registryContract.setCountryCode(fileLine.readString(ColumnsNames.COUNTRY_ID));
		registryContract.setBankId(fileLine.readString(ColumnsNames.ENTITY_ID));
		registryContract.setCounterpart(fileLine.readString(ColumnsNames.COUNTERPART_ID));

		String dependId = fileLine.readString(ColumnsNames.DEPENDENCY_ID);
		if (dependId==null || "".equals(dependId.trim())){
			dependId = Constants.SUBLEVEL_OTHER;
		}
		registryContract.setSubLevel(dependId);


		registryContract.setContractFormatIuc(fileLine.readString(ColumnsNames.IUC));

		String isinId = fileLine.readString(ColumnsNames.ISIN);
		if (isinId==null || "".equals(isinId.trim())){
			isinId = Constants.ISIN_0;
		}
		registryContract.setInvestmentFundIsin(isinId);

		
		String marketId = fileLine.readString(ColumnsNames.MARKET_ID);
		if (marketId==null || "".equals(marketId.trim())){
			marketId = Constants.INTERNAL_MARKET_OTHER;
		}
		registryContract.setInternalMarket(marketId);
		

		registryContract.setParentId(fileLine.readString(ColumnsNames.PARENT_ID));
// Se añade el signo, ya que el campo tiene una posicion menos respecto al resto de cantidades
		registryContract.setInvestmentFundSharesNumber(Utils.stringToDouble("+"+fileLine.readString(ColumnsNames.PRODUCT_AMOUNT)));

		String sAssessmentDate = fileLine.readString(ColumnsNames.VALUE_DATE);
		if (sAssessmentDate != null) {
			LocalDate localDate= LocalDate.of(Integer.parseInt(sAssessmentDate.substring(0, 4)),Integer.parseInt(sAssessmentDate.substring(5, 7)),Integer.parseInt(sAssessmentDate.substring(8,10)));
			registryContract.setAssessmentDate(Date.from(localDate.atStartOfDay(ZoneId.of(Constants.TIMEZONE_UTC)).toInstant()));
		}

		registryContract.setLocalCurrencyId(fileLine.readString(ColumnsNames.CURRENCY_ID));
		registryContract.setQuotationsAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.QTN_AMOUNT_EUR)));
		registryContract.setSettlementAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.IMP_VALIQ_EUR)));
		registryContract.setAssetmentAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.EQUITY_AMOUNT_EUR)));
		registryContract.setContributionsAmount( Utils.stringToDouble(fileLine.readString(ColumnsNames.CONTRIBUTION_AMOUNT_EUR)));
		registryContract.setDetractionsAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.DETRACTIONS_AMOUNT_EUR)));
		registryContract.setNetContributionsAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.NET_CONT_AMOUNT_EUR)));
		registryContract.setExpensesAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.CURNCY_EXPENSE_AMOUNT)));
		registryContract.setIncomeAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.INCOME_AMOUNT)));
		registryContract.setProfitDerivativeAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.DERIVED_PRFT_AMOUNT_EUR)));
		registryContract.setDailyProfitAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.PROFITABILITY_AMOUNT)));
		registryContract.setLocalCurrencyIdQuotationsAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.QTN_AMOUNT)));
		registryContract.setLocalCurrencyIdSettlementAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.SETTL_AMOUNT)));
		registryContract.setLocalCurrencyIdAssetmentAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.LCUR_EQUITY_AMOUNT)));
		registryContract.setLocalCurrencyIdContributionsAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.CONT_AMOUNT)));
		registryContract.setLocalCurrencyIdDetractionsAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.DETRACTIONS_AMOUNT_LCUR)));
		registryContract.setLocalCurrencyIdNetContributionsAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.NET_CONT_AMOUNT_LCUR)));
		registryContract.setLocalCurrencyIdExpensesAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.EXPENSES_AMOUNT)));
		registryContract.setLocalCurrencyIdIncomeAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.INCOME_AMOUNT_LCUR)));
		registryContract.setLocalCurrencyIdProfitDerivativeAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.DERIVED_PROFIT_AMOUNT)));
		registryContract.setLocalCurrencyIdDailyProfitAmount(Utils.stringToDouble(fileLine.readString(ColumnsNames.DAILY_PROFIT_AMOUNT)));
		registryContract.setTransferMark(fileLine.readString(ColumnsNames.TRANSFER_IND_TYPE));
		registryContract.setRebalancedMark(fileLine.readString(ColumnsNames.REBALANCER_IND_TYPE));
		String sAuditInsertDate = fileLine.readString(ColumnsNames.AUDIT_INSERT_DATE);
		if (sAuditInsertDate != null) {
			LocalDate localDate= LocalDate.of(Integer.parseInt(sAuditInsertDate.substring(0, 4)),Integer.parseInt(sAuditInsertDate.substring(5, 7)),Integer.parseInt(sAuditInsertDate.substring(8,10)));
			registryContract.setAuditInsertDate(Date.from(localDate.atStartOfDay(ZoneId.of(Constants.TIMEZONE_UTC)).toInstant()));
		}
		registryContract.setAuditInsertUserId(fileLine.readString(ColumnsNames.AUDIT_INSERTION_USER_ID));
		registryContract.setAuditChangeUserId(fileLine.readString(ColumnsNames.AUDIT_INSERTION_USER_ID));

		LocalDate localDate = LocalDate.now();
		registryContract.setAuditChangeDate(Date.from(localDate.atStartOfDay(ZoneId.of(Constants.TIMEZONE_UTC)).toInstant()));

		LOGGER.info("KIFVJ001 - Mapper - END");
		return registryContract;
	}
}
