package com.bbva.kifv.batch;

import com.bbva.kifv.batch.utils.Utils;
import com.bbva.kifv.dto.fup.RegistryContracts;
import com.bbva.kifv.lib.r002.KIFVR002;
import com.bbva.mmtp.lib.rrea.MMTPRREA;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WriterContract implements ItemWriter<RegistryContracts> {

    //Variables
    private KIFVR002 kifvR002; // Mongo batch access library
    private String[] activeCollections;
    
    private MMTPRREA mmtpRREA;
    private String date;
    private String process;

    //Log constant
    private static final Logger LOGGER = LoggerFactory.getLogger(WriterContract.class);

    //Setters
    public void setKifvR002(KIFVR002 kifvR002) {
        this.kifvR002 = kifvR002;
    }
    
    public void setMmtpRREA(MMTPRREA mmtpRREA) {
		this.mmtpRREA = mmtpRREA;
	}
    
	public void setDate(String date) {
		this.date = date;
	}

	public void setProcess(String process) {
		this.process = process;
	}
	
    public void setActiveCollections(String[] activeCollections) {this.activeCollections = activeCollections;}


    public void write(List<? extends RegistryContracts> registryContractsList) {

        LOGGER.info("KIFVJ001 - WriterContract - START");

        //Map where the contracts will be stored (key: year, value: List_of_contracts)
        Map<String, List<RegistryContracts>> yearsToRegistryContracts = new HashMap<>();

        if (!registryContractsList.isEmpty()) {

            for (RegistryContracts registryContract : registryContractsList) {
                String year = String.valueOf(Utils.getYearDateRegister(registryContract.getDate()));

                if (Arrays.asList(activeCollections).contains(year)) {
                    List<RegistryContracts> listRegistryContracts = yearsToRegistryContracts.get(year); //Check if that key already has value

                    if (listRegistryContracts == null) { //If don't have it, a new list is created and the contract is added
                        listRegistryContracts = new ArrayList<>();
                    }
                    listRegistryContracts.add(registryContract);
                    yearsToRegistryContracts.put(year, listRegistryContracts);
                }
            }

            String message = MessageFormat.format("KIFVJ001 - WriterContract - Documents to insert:  {0}", registryContractsList);
            LOGGER.info(message);

    		String dateProcess = date.substring(0,4) + "/" +  date.substring(4,6) + "/" + date.substring(6,date.length()) ;
            Map<String, Object> paramInput = new HashMap<>();
            paramInput.put("UPD" ,  "0"); 
            paramInput.put("INS" ,  "0"); 
            paramInput.put("IDPROCESS",	 "KIFVJ001");
            paramInput.put("PROCESS",    process);
            paramInput.put("FORMATDATE", "yyyy/mm/dd");
            paramInput.put("ENTITYID",   "0074");
            paramInput.put("CUSTOM",     "KIFV"); 		
            paramInput.put("DATEPROCESS",dateProcess);
            
            if (!yearsToRegistryContracts.isEmpty()) {
                for (Map.Entry<String, List<RegistryContracts>> entry : yearsToRegistryContracts.entrySet()) {
                    kifvR002.executeInsertRegistryContract(entry.getValue(), entry.getKey());
                    
                    paramInput.put("REGS",  String.valueOf(entry.getValue().size())); /*READ*/
					mmtpRREA.executeInsUpdateRea(paramInput);
                }
            }
        }
        LOGGER.info("KIFVJ001 - WriterContract - END");
    }
}
