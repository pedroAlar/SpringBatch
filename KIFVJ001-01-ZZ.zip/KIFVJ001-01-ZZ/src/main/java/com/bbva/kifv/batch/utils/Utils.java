package com.bbva.kifv.batch.utils;

import java.util.Calendar;
import java.util.Date;


public class Utils {

	//Private constructor to hide the implicit public one.
	private Utils(){}

	/**
	 * Method that converts a sString to Double
	 * @param imp value received as String
	 * @return the value received as Double
	 */
	public static Double stringToDouble(String imp)  {
		
		Double impDouble;
		if (imp!=null && !"".equals(imp)){
			impDouble= Double.parseDouble(imp.substring(1, 21)+"."+imp.substring(21));
			
			if (Constants.NEGATIVE_NUMBER_OPERATOR.equals( imp.substring(0, 1) )){
				impDouble = impDouble *(-1);
			}
		}else{
			impDouble = 0.0;
		}
		return impDouble;
	}



	/**
	 * Method  that gets year from a date
	 * @param date date received
	 * @return int representing the year
	 */
	public static int getYearDateRegister(Date date) {

		Calendar cDate = Calendar.getInstance();
		int dateYear = cDate.get(Calendar.YEAR);
		if (date!=null){
			cDate.setTime(date);
			dateYear = cDate.get(Calendar.YEAR);
		}
		return dateYear;
	}
	
}
