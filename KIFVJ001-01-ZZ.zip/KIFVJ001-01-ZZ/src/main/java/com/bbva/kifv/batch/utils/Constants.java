package com.bbva.kifv.batch.utils;

public class Constants {

	//Private constructor to hide the implicit public one.
	private Constants(){}

	//---------  File name  --------------
	public static final String DIRECTORY_FILE_NAME = "file:";
	public static final String FILE_PREFIX = "KIFV_D02_";
	public static final String DAILY_FUNDS_FILE_NAME = "_FONDOS";
	public static final String DAILY_HISTORIC_FUNDS_FILE_NAME = "_HISTORICO_FONDOS";

	//--------- Timezone ---------------
	public static final String TIMEZONE_UTC = "UTC";

	public static final String NEGATIVE_NUMBER_OPERATOR = "-";

	public static final String ISIN_0 = "000000000000";
	public static final String INTERNAL_MARKET_OTHER = "0000";
	public static final String SUBLEVEL_OTHER = "000000000";
}
