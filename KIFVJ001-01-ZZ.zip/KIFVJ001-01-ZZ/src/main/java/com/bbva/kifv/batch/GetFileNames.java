package com.bbva.kifv.batch;

import com.bbva.kifv.batch.utils.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;

import java.io.File;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class GetFileNames implements Tasklet {

    private String directory;

    //Log constant
    private static final Logger LOGGER = LoggerFactory.getLogger(GetFileNames.class);

    //Getter & Setter
    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        LOGGER.info("KIFVJ001 - START");
        LOGGER.info("KIFVJ001 - GetFileNames - START");

        Map<String, Object> parameters = chunkContext.getStepContext().getJobParameters();

        String fileDate = getFileDate(parameters);

        // num parameter check: if it comes to null it is set to ""
        String fileNum = (String) parameters.get("num");
        if (fileNum == null) fileNum = "";

        // his parameter check: if it comes to null or "" it is set to "N" (otherwise it should come to "Y")
        String historic = (String) parameters.get("his");
        if (historic == null || historic.equals("")) historic = "N";

        String logParameters =  MessageFormat.format("KIFVJ001 - GetFileNames - date: {0}  num: {1} his: {2} ", fileDate,fileNum,historic);
        LOGGER.info(logParameters);

        //List containing the input file names based on "date", "num" and "his"
        List<String> files = getFiles(fileDate, fileNum, historic);

        //They are saved in jobContext for use in other steps
        ExecutionContext jobContext = chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext();
        jobContext.put("FILESIN", files);

        String loFiles =  MessageFormat.format("KIFVJ001 - GetFileNames - Files: {0}", files);
        LOGGER.info(loFiles);
        LOGGER.info("KIFVJ001 - GetFileNames - END");
        return null;
    }


    /**
     * @param parameters parameters received by the batch as input
     * @return Date in String format
     * In case the date is provided as input, the same date is returned
     * Otherwise the odate parameter is returned.
     */
    private String getFileDate(Map<String, Object> parameters) {

        String fileDate = (String) parameters.get("date");

        if (fileDate == null || fileDate.isEmpty()) {
            fileDate = (String) parameters.get("ODATE");
        }
        return fileDate;
    }


    /**
     * @param fileDate Date of the file to process
     * @param fileNunStr number of the file to process
     * @param historic  "Y" in case of being historical "N" if not
     * @return A list with the names of the files to process
     */
    public List<String> getFiles(String fileDate, String fileNunStr, String historic) {

        List<String> files = new ArrayList<>();
        File folder = new File(directory);
        File[] listOfFiles = folder.listFiles();

        String fundsFileName = Constants.DAILY_FUNDS_FILE_NAME;
        if (historic.equals("Y")) fundsFileName = Constants.DAILY_HISTORIC_FUNDS_FILE_NAME;

        if(listOfFiles!=null) {
            for (File file : listOfFiles) {

                if (file.isFile()) {

                    //Format file name as: KIFV_D02_AAAAMMDD_FONDOS
                    String fileName = Constants.FILE_PREFIX + fileDate + fundsFileName;

                    String name = file.getName();

                    boolean isValidFile = checkFileValidity(name, fileName, fileNunStr);
                    if (isValidFile) {
                        files.add(Constants.DIRECTORY_FILE_NAME + directory + file.getName());
                    }
                }
            }
        }
        return files;
    }


    /**
     * @param name name of the file to check
     * @param fileName KIFV_D02_FONDOS_AAAAMMDD
     * @param fileNumStr parameter with the file number as string
     * @return true if the file is valid false if it is not
     */
    public boolean checkFileValidity(String name, String fileName, String fileNumStr) {

        if (name.startsWith(fileName)) {

            //If it has an extension, it is omitted
            if (name.lastIndexOf('.') > 0) {
                name = name.substring(0, name.lastIndexOf('.'));
            }
            return fileNumStr == null || fileNumStr.isEmpty() || name.endsWith(fileNumStr);
        }
        return false;
    }
}
