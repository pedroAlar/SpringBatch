package com.bbva.kifv.batch;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/batch/beans/KIFVJ001-01-ZZ-beans.xml",
		"classpath:/META-INF/spring/batch/jobs/jobs-KIFVJ001-01-ZZ-context.xml",
		"classpath:/META-INF/spring/jobs-KIFVJ001-01-ZZ-runner-context.xml" })
public class GetFileNamesTest {

	GetFileNames getFileNames = new GetFileNames();

	@Test
	public void testGetFicheros(){
		getFileNames.setDirectory("./src/test/resources");
		getFileNames.getFiles(null, "2", "S");
		getFileNames.getFiles("", null, "N");
		getFileNames.getFiles("", "2", "");

		Assert.assertTrue(true);
	}

	@Test
	public void testGetFicherosMx(){
		GetFileNames getFileNames = new GetFileNames();
		getFileNames.setDirectory("./src/test/resources");
		getFileNames.getFiles("20210820", null, "N");

		Assert.assertTrue(true);
	}

}
