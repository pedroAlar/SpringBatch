package com.bbva.kifv.batch;

import com.bbva.kifv.batch.utils.Utils;
import org.junit.Assert;
import org.junit.Test;

public class UtilsTest {

	@Test
	public void testStringToDouble() {
		String imp = "-12345678901234567890123456";
		Double prueba = Utils.stringToDouble(imp);
		Double d = -12345678901234567890.123456;
		Assert.assertEquals(prueba, d);

		String imp2 = "";
		Double prueba2 = Utils.stringToDouble(imp2);
		Double d2 = 0.0;
		Assert.assertEquals(prueba2, d2);
	}



}
