package com.bbva.kifv.batch;

import com.bbva.kifv.batch.mongo.ColumnsNames;
import com.bbva.kifv.dto.fup.RegistryContracts;
import com.bbva.kifv.mock.KIFVR002Mock;
import com.bbva.kifv.mock.MMTPRREAMock;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

/**
 * Test for batch process KIFVJ001-01-ZZ
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/META-INF/spring/batch/beans/KIFVJ001-01-ZZ-beans.xml","classpath:/META-INF/spring/batch/jobs/jobs-KIFVJ001-01-ZZ-context.xml","classpath:/META-INF/spring/jobs-KIFVJ001-01-ZZ-runner-context.xml"})
 public class KIFVJ00101ZZFunctionalTest{

	@Autowired
	private JobLauncherTestUtils jobLauncherTestUtils;


	@InjectMocks
    GetFileNames getFileNames = new GetFileNames();
	
	@InjectMocks
    Mapper mapper = new Mapper();
	
	@InjectMocks
    WriterContract writerContract = new WriterContract();
	
	@Mock
    StepContribution stepContribution;

    @Mock
    ChunkContext chunkContext;

    @Test
    public void testWriterContract(){
        writerContract.setKifvR002(new KIFVR002Mock());
        writerContract.setMmtpRREA(new MMTPRREAMock());
        writerContract.setDate("20221111");
        writerContract.setProcess("KIFVPPP001");
		writerContract.setActiveCollections(new String[]{"2016", "2017", "2018", "2019", "2020", "2021", "2022"});
        writerContract.write(Collections.singletonList(new RegistryContracts()));
        Assert.assertNotNull("test");
    }
    

    @Test
    public void testMapper() {
        mapper.mapFieldSet(new FieldSet() {

			@Override
			public int getFieldCount() {
				return 0;
			}

			@Override
			public String[] getNames() {
				return null;
			}

			@Override
			public Properties getProperties() {
				return null;
			}

			@Override
			public String[] getValues() {
				return null;
			}

			@Override
			public boolean hasNames() {
				return false;
			}

			@Override
			public BigDecimal readBigDecimal(int arg0) {
				return null;
			}

			@Override
			public BigDecimal readBigDecimal(String arg0) {
				return null;
			}

			@Override
			public BigDecimal readBigDecimal(int arg0, BigDecimal arg1) {
				return null;
			}

			@Override
			public BigDecimal readBigDecimal(String arg0, BigDecimal arg1) {
				return null;
			}

			@Override
			public boolean readBoolean(int arg0) {
				return false;
			}

			@Override
			public boolean readBoolean(String arg0) {
				return false;
			}

			@Override
			public boolean readBoolean(int arg0, String arg1) {
				return false;
			}

			@Override
			public boolean readBoolean(String arg0, String arg1) {
				return false;
			}

			@Override
			public byte readByte(int arg0) {
				return 0;
			}

			@Override
			public byte readByte(String arg0) {
				return 0;
			}

			@Override
			public char readChar(int arg0) {
				return 0;
			}

			@Override
			public char readChar(String arg0) {
				return 0;
			}

			@Override
			public Date readDate(int arg0) {
				return null;
			}

			@Override
			public Date readDate(String arg0) {
				return null;
			}

			@Override
			public Date readDate(int arg0, Date arg1) {
				return null;
			}

			@Override
			public Date readDate(String arg0, Date arg1) {
				return null;
			}

			@Override
			public Date readDate(int arg0, String arg1) {
				return null;
			}

			@Override
			public Date readDate(String arg0, String arg1) {
				return null;
			}

			@Override
			public Date readDate(int arg0, String arg1, Date arg2) {
				return null;
			}

			@Override
			public Date readDate(String arg0, String arg1, Date arg2) {
				return null;
			}

			@Override
			public double readDouble(int arg0) {
				return 0;
			}

			@Override
			public double readDouble(String arg0) {
				return 0;
			}

			@Override
			public float readFloat(int arg0) {
				return 0;
			}

			@Override
			public float readFloat(String arg0) {
				return 0;
			}

			@Override
			public int readInt(int arg0) {
				return 0;
			}

			@Override
			public int readInt(String arg0) {
				return 0;
			}

			@Override
			public int readInt(int arg0, int arg1) {
				return 0;
			}

			@Override
			public int readInt(String arg0, int arg1) {
				return 0;
			}

			@Override
			public long readLong(int arg0) {
				return 0;
			}

			@Override
			public long readLong(String arg0) {
				return 0;
			}

			@Override
			public long readLong(int arg0, long arg1) {
				return 0;
			}

			@Override
			public long readLong(String arg0, long arg1) {
				return 0;
			}

			@Override
			public String readRawString(int arg0) {
				return null;
			}

			@Override
			public String readRawString(String arg0) {
				return null;
			}

			@Override
			public short readShort(int arg0) {
				return 0;
			}

			@Override
			public short readShort(String arg0) {
				return 0;
			}

			@Override
			public String readString(int arg0) {
				return null;
			}

			@Override
			public String readString(String s) {
				if (ColumnsNames.DATA_DATE.equals(s) ||ColumnsNames.VALUE_DATE.equals(s) ||ColumnsNames.AUDIT_INSERT_DATE.equals(s) ) {
                    return "2021-06-02";
                }
                return "12345678901234567890123456";
			}
        });
        }

	@Test
	public void testLaunchJob() throws Exception {
		//Add parameters to job
		final JobParameter jobParameter = new JobParameter("20211111");
		final HashMap<String, JobParameter> parameters1 = new HashMap<>();
		parameters1.put("date", jobParameter);
		final JobParameters jobParameters1 = new JobParameters(parameters1);
		final JobExecution jobExecution1 = jobLauncherTestUtils.launchJob(jobParameters1);
		Assert.assertEquals(ExitStatus.COMPLETED,jobExecution1.getExitStatus());
	}

	@Test
	public void testLaunchJobOnlyDate() throws Exception {

		//First parameter
		final JobParameter jobParameter = new JobParameter("20211118");

		//Add parameters to job
		final HashMap<String, JobParameter> parameters1 = new HashMap<>();
		parameters1.put("date", jobParameter);
		final JobParameters jobParameters1 = new JobParameters(parameters1);
		final JobExecution jobExecution1 = jobLauncherTestUtils.launchJob(jobParameters1);
		Assert.assertEquals(ExitStatus.COMPLETED,jobExecution1.getExitStatus());
	}

	@Test
	public void testLaunchJobDateAndNum() throws Exception {

		//First parameter
		final JobParameter jobParameterDate = new JobParameter("20211112");
		final JobParameter jobParameterNum = new JobParameter("11");

		//Add parameters to job
		final HashMap<String, JobParameter> parameters1 = new HashMap<>();
		parameters1.put("date", jobParameterDate);
		parameters1.put("num", jobParameterNum);

		final JobParameters jobParameters1 = new JobParameters(parameters1);
		final JobExecution jobExecution1 = jobLauncherTestUtils.launchJob(jobParameters1);
		Assert.assertEquals(ExitStatus.COMPLETED,jobExecution1.getExitStatus());
	}

	@Test
	public void testLaunchJobDateNumHis() throws Exception {

		//First parameter
		final JobParameter jobParameterDate = new JobParameter("20211112");
		final JobParameter jobParameterNum = new JobParameter("12");
		final JobParameter jobParameterHis = new JobParameter("");

		//Add parameters to job
		final HashMap<String, JobParameter> parameters1 = new HashMap<>();
		parameters1.put("date", jobParameterDate);
		parameters1.put("num", jobParameterNum);
		parameters1.put("his", jobParameterHis);

		final JobParameters jobParameters1 = new JobParameters(parameters1);
		final JobExecution jobExecution1 = jobLauncherTestUtils.launchJob(jobParameters1);
		Assert.assertEquals(ExitStatus.COMPLETED,jobExecution1.getExitStatus());
	}
}
