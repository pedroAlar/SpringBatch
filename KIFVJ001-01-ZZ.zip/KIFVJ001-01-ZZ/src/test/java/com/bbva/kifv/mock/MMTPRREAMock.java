package com.bbva.kifv.mock;

import java.util.HashMap;
import java.util.Map;

import com.bbva.mmtp.lib.rrea.MMTPRREA;

public class MMTPRREAMock implements MMTPRREA {

	@Override
	public Integer executeInsUpdateRea(Map<String, Object> paramInput) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Long executeSelectRea(String process, String odate) {
		// TODO lAuto-generated method stub
		return 0L;
	}

	@Override
	public Map<String, Object> executeSelectReaMap(String process, String odate) {
		Map<String, Object> mapResponse = new HashMap<String, Object>();
		mapResponse.put("REGS", "1");
		return mapResponse ;
	}
	

	
}
