package com.bbva.kifv.mock;

import java.util.List;

import com.bbva.kifv.dto.fup.Contract;
import com.bbva.kifv.dto.fup.ContractDetail;
import com.bbva.kifv.dto.fup.Dates;
import com.bbva.kifv.dto.fup.RegistryContracts;
import com.bbva.kifv.lib.r002.KIFVR002;

public class KIFVR002Mock  implements KIFVR002{

	@Override
	public void executeInsertRegistryContract(List<RegistryContracts> arg0, String arg1) {
		// TODO Auto-generated method stub
	}

	@Override
	public List<ContractDetail> executeGetRegistryContract(List<Contract> registryContractsList, Dates dates) {
		return null;
	}

	@Override
	public List<ContractDetail> executeGetFirstRegistryDate(List<Contract> contractsDataList) {
		return null;
	}

}
