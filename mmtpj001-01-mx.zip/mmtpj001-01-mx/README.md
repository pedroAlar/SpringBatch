# SDATOOL-35157 DIFO Invest Consulta de Inversiones de la cuenta del cliente
===========================================================

## Descripción del proyecto
=============================

Aprovisionara Contratos Activos 
Se consultara el estado de las inversionas realizadas por el cliente, se pretende hacer mejoras 
al flujo actual BBVA Invest, que es flujo de inversiones DIY para inversión en portafolios de inversión.

La informacion que se aprovisionara:

CAMPO que se aprovisionaran en APX.
Entidad Contrato,
oficina apertura Contrato,
digitos verificadores Contrato,
Contrato,
Fecha alta, 
Fecha baja,
Moneda,
Fecha de bloqueo,
Estatus Contrato,
Canal de Alta,
Entidad Cuenta Eje,
Oficina Cuenta Eje,
Cuenta  Cuenta Eje,
Marca invest,
CR gestor,
Usuario de modificacion,
Fecha de Actualizacion,  
CTADATOS,
CR Ejecutivo

### Libreria MMTPR002
=============================

Aprovisiona contratos Activos

Mediante la libreria MMTPR002 y metodo executeGetProvisioningContracts

BBVA Invest es un flujo de la banca en línea para que los clientes de comercial puedan realizar contrataciones
y compras de productos de inversión mediante el uso de objetivos personalizados, así como de anaquel de
inversiones personalizado a los objetivos del mismo.

#### Conexión a base de datos
=============================

JDBC

##### Librerias [Interface]
===================

MMTPR002

Libreria que insertara los contratos Activos

##### Metodos expuestos
-------------------------------------------
executeGetProvisioningContracts Aprovisiona contratos Activos asociados a la cuenta
				

